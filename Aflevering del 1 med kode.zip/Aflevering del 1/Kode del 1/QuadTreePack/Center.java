package QuadTreePack;

/**
 * Class to contain center coordinates for the Boundary object.
 * @author Gruppe A
 */
public class Center
{
    double xc, yc;
}
