package QuadTreePack;

/**
 * Enum to differentiate between directions when dividing a quad.
 * @author Gruppe A
 */
public enum NSEW
{
    NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST, ROOT
}
